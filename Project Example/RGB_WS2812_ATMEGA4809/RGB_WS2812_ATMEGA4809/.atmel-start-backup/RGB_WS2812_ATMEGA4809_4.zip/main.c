#include <atmel_start.h>
//#include "util/delay.h"
#include "ws2812B_driver_basic.h"

void toggle_led_blue(void);
void rgb_toggle(int arg);
void led_fade(void);

uint32_t blinkCheck_blue, rgb_toggle_check, rgb_toggle_check2;
bool rgb_status, fullBrightness;

volatile uint8_t colors[] = {0, 255, 0};
uint8_t count;

#define NUMBER_LED      4

const uint8_t colorArray[3] = {152,155, 122};  /*Red, Green, blue*/

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	ws2812b_info_t ws2812bInfo;
	
	_delay_ms(2000);

	ws2812b_basic_initialize(NUMBER_LED);
	ws2812b_info(&ws2812bInfo);

	ws2812b_interface_debug_print("chip name: \t%s\n\r", ws2812bInfo.chip_Name);
	ws2812b_interface_debug_print("Manufacturer: \t%s\n\r", ws2812bInfo.manufacturer_name);
	ws2812b_interface_debug_print("Interface: \t%s\n\r", ws2812bInfo.interface);
	ws2812b_interface_debug_print("Supply max voltage: \t%0.2fV\n\r", ws2812bInfo.supply_Voltage_max_V);
	ws2812b_interface_debug_print("Supply min voltage: \t%0.2fV\n\r", ws2812bInfo.supply_voltage_min_v);
	ws2812b_interface_debug_print("Temperature Max: \t%.1fC\n\r", ws2812bInfo.temperature_max);
	ws2812b_interface_debug_print("Driver version: \tV%.1f\n\r", (ws2812bInfo.driver_version / 1000));

	/* Replace with your application code */
	while (1) {
          
		  //ws2812b_basic_write(1, WS2812b_COLOR_GREEN);
		  //ws2812b_basic_customized_color(2, colorArray);

		  
	}
	return 1;
}

